// ============================================
// CHATUR HOME SCREEN (Enhanced Version)
// ============================================

import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:chatur_frontend/Events/screens/main_event_screen.dart';
import 'package:chatur_frontend/Events/services/notification_service.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final currentUser = FirebaseAuth.instance.currentUser;
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userName = currentUser?.displayName ?? 'User';
    final userEmail = currentUser?.email ?? 'user@example.com';

    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FF),
      appBar: _buildAppBar(),
      drawer: _buildDrawer(userName, userEmail),
      body: _buildBody(userName),
      bottomNavigationBar: _bottomNavigationBar(),
    );
  }

  // ============================================
  // APP BAR
  // ============================================
  AppBar _buildAppBar() {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF5D3FD3), Color(0xFF7A5AF8)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
      ),
      title: const Text(
        "CHATUR",
        style: TextStyle(fontSize: 23, fontWeight: FontWeight.w700, color: Colors.white),
      ),
      actions: [
        StreamBuilder<int>(
          stream: NotificationService.getUnreadCountStream(),
          builder: (context, snapshot) {
            final unread = snapshot.data ?? 0;
            return Stack(
              children: [
                IconButton(
                  icon: const Icon(Icons.notifications_outlined, color: Colors.white, size: 26),
                  onPressed: () => ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text("Notifications: $unread"))),
                ),
                if (unread > 0)
                  Positioned(
                    right: 5,
                    top: 5,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                      child: Text(
                        unread > 99 ? "99+" : "$unread",
                        style: const TextStyle(fontSize: 9, color: Colors.white, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
        const SizedBox(width: 10),
      ],
    );
  }

  // ============================================
  // DRAWER
  // ============================================
  Drawer _buildDrawer(String userName, String userEmail) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            height: 200,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF5D3FD3), Color(0xFF9370F6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Hero(
                  tag: "profilePic",
                  child: CircleAvatar(
                    radius: 36,
                    backgroundColor: Colors.white,
                    child: ClipOval(
                      child: CachedNetworkImage(
                        imageUrl: currentUser?.photoURL ?? "",
                        width: 72,
                        height: 72,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(userName, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)),
                Text(userEmail, style: const TextStyle(color: Colors.white70, fontSize: 13)),
              ],
            ),
          ),
          _drawerItem(Icons.home, "Home"),
          _drawerItem(Icons.person, "Profile"),
          _drawerItem(Icons.settings, "Settings"),
          const Divider(),
          _drawerItem(Icons.help_outline, "Help & Support"),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text("Logout", style: TextStyle(color: Colors.red)),
            onTap: _showLogoutDialog,
          ),
        ],
      ),
    );
  }

  ListTile _drawerItem(IconData icon, String label) {
    return ListTile(
      leading: Icon(icon, color: Colors.deepPurple),
      title: Text(label),
      onTap: () => Navigator.pop(context),
    );
  }

  // ============================================
  // BODY
  // ============================================
  Widget _buildBody(String userName) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          const SizedBox(height: 20),
          _welcomeCard(userName),
          const SizedBox(height: 20),
          _statsRow(),
          const SizedBox(height: 24),
          _sectionTitle("Explore Features"),
          _featureGrid(),
          const SizedBox(height: 24),
          _sectionTitle("Quick Access"),
          _quickAccess(),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // ============================================
  // WELCOME CARD (GLASS)
  // ============================================
  Widget _welcomeCard(String name) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: _glassBox(),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: Colors.deepPurple.withOpacity(.2), blurRadius: 12)],
            ),
            child: const Icon(Icons.waving_hand_rounded, color: Colors.orange, size: 32),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Welcome,", style: TextStyle(fontSize: 13, color: Colors.black54)),
                Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                const Text("Ready to explore today? 🚀", style: TextStyle(fontSize: 12, color: Colors.black54)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  BoxDecoration _glassBox() {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: Colors.white.withOpacity(.5)),
      gradient: LinearGradient(
        colors: [Colors.white.withOpacity(.7), Colors.white.withOpacity(.3)],
      ),
      boxShadow: [BoxShadow(color: Colors.deepPurple.withOpacity(.1), blurRadius: 12, offset: const Offset(0, 6))],
      backgroundBlendMode: BlendMode.overlay,
    );
  }

  // ============================================
  // STATS CARDS (GLASS)
  // ============================================
  Widget _statsRow() {
    return Row(
      children: [
        Expanded(child: _statTile(Icons.event, "15+", "Events", Colors.blue)),
        const SizedBox(width: 10),
        Expanded(child: _statTile(Icons.work, "50+", "Skills", Colors.green)),
        const SizedBox(width: 10),
        Expanded(child: _statTile(Icons.account_balance, "100+", "Schemes", Colors.orange)),
      ],
    );
  }

  Widget _statTile(IconData icon, String count, String label, Color color) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _glassBox(),
      child: Column(
        children: [
          Icon(icon, color: color, size: 26),
          Text(count, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
        ],
      ),
    );
  }

  // ============================================
  // FEATURES GRID WITH SCALE TAP
  // ============================================
  Widget _featureGrid() {
    return GridView.count(
      shrinkWrap: true,
      crossAxisCount: 2,
      childAspectRatio: 1.15,
      mainAxisSpacing: 14,
      crossAxisSpacing: 14,
      physics: const NeverScrollableScrollPhysics(),
      children: [
        _featureCard(Icons.work_outline, "Find Skills", "Discover talent", Colors.blue, () {}),
        _featureCard(Icons.event, "Events", "Community hub", Colors.purple,
            () => Navigator.push(context, MaterialPageRoute(builder: (_) => MainEventScreen()))),
        _featureCard(Icons.chat_bubble_outline, "Chatbot", "Ask schemes", Colors.green, () {}),
        _featureCard(Icons.account_balance, "Schemes", "Govt benefits", Colors.orange, () {}),
      ],
    );
  }

  Widget _featureCard(IconData icon, String title, String sub, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [color.withOpacity(.8), color]),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: color.withOpacity(.4), blurRadius: 16, offset: const Offset(0, 7))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, color: Colors.white, size: 30),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white)),
                Text(sub, style: const TextStyle(fontSize: 12, color: Colors.white70)),
              ],
            )
          ],
        ),
      ),
    );
  }

  // ============================================
  // QUICK ACCESS
  // ============================================
  Widget _quickAccess() {
    return Column(
      children: [
        _quickTile(Icons.post_add, "Post Your Skill", "Let employers find you", Colors.teal, () {}),
        _quickTile(Icons.calendar_today, "View Calendar", "Upcoming events", Colors.indigo, () {}),
        _quickTile(Icons.location_on, "Find Nearby", "Workers near you", Colors.red, () {}),
      ],
    );
  }

  Widget _quickTile(IconData icon, String title, String sub, Color color, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: _glassBox(),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(backgroundColor: color.withOpacity(.2), child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }

  // ============================================
  // SECTION TITLE
  // ============================================
  Widget _sectionTitle(String title) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
    );
  }

  // ============================================
  // BOTTOM NAV (NEO MORPHIC)
  // ============================================
  Widget _bottomNavigationBar() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: const Offset(0, -4))],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _navItem(Icons.home, true),
          _navItem(Icons.search, false),
          _navItem(Icons.add_circle_outline, false),
          _navItem(Icons.message_outlined, false),
          _navItem(Icons.person_outline, false),
        ],
      ),
    );
  }

  Widget _navItem(IconData icon, bool active) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: active ? Colors.deepPurple.withOpacity(.15) : Colors.transparent,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(icon, color: active ? Colors.deepPurple : Colors.black45),
    );
  }

  // ============================================
  // LOGOUT DIALOG
  // ============================================
  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(children: const [Icon(Icons.logout, color: Colors.red), SizedBox(width: 8), Text("Logout")]),
        content: const Text("Are you sure you want to logout?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text("Logout"),
          ),
        ],
      ),
    );
  }
}
